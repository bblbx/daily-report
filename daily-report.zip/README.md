# 每日热点日报 📰

自动更新的热点聚合网站，每天早晨 8 点推送 + 自动抓取热点。

## 部署到 Gitee Pages（5 分钟搞定）

### 步骤 1：创建 Gitee 仓库
1. 登录 Gitee（码云）
2. 创建新仓库，比如叫 `daily-report`
3. 仓库设为 **公开**（Gitee Pages 免费）

### 步骤 2：推送代码
```bash
cd /root/.openclaw/workspace/daily-report
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://gitee.com/YOUR_USERNAME/daily-report.git
git push -u origin main
```

### 步骤 3：开启 Gitee Pages
1. 进入仓库 **管理** → **Pages**
2. 源分支选择 `main`（或 `gh-pages`）
3. 点击 **启动 Pages**
4. 等待部署完成（约 1-2 分钟）

### 步骤 4：获取链接
部署完成后，你的网站链接是：
```
https://YOUR_USERNAME.gitee.io/daily-report/
```

---

## 自动更新

✅ **已配置自动抓取**：每天北京时间 8 点自动：
1. 运行 `scrape.py` 抓取热点
2. 更新 `data.js` 并提交
3. 自动部署到 Gitee Pages

你也可以手动触发：进入 Gitee 仓库 → 构建 → 工作流 → 手动运行

---

## 文件说明

- `index.html` - 主页面（卡片式布局）
- `data.js` - 热点数据（每天自动更新）
- `scrape.py` - 热点抓取脚本
- `.gitee/workflows/` - Gitee 自动部署配置

---

## 定制样式

修改 `index.html` 中的 CSS 可以调整：
- 配色方案
- 卡片样式
- 字体大小
